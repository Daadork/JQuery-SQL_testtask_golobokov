$(document).ready(function () {

    $(":input").on("click", function () {
        //alert(event.type);
    });

    $('#Block1').on('input', function () {
        $('.input.-active').removeClass('-active');

        if ($('.input[id="Block1' + $(this).val() + '"]').length > 0) {
            $('.input[id="Block1' + $(this).val() + '"]')
                .addClass('-active');
        }
    });

    $("#PopupDIV").on("click", function (event, type) {
        alert(event.type);
    });

});