select * 
from Table_1 left join Table_2 on Table_1.EntityID = Table_2.EntityID


SELECT Table_2.*
FROM Table_2
LEFT JOIN Table_1 ON (Table_2.EntityID=Table_1.EntityID)
WHERE Table_1.EntityID IS NULL


SELECT PositionQuantity, PositionPrice, PositionQuantity * PositionPrice AS NewCatalog
FROM Table_1    
ORDER BY PositionQuantity ASC;  
GO 

SELECT PositionQuantity, PositionPrice, PositionQuantity * PositionPrice AS NewCatalog
FROM Table_1    
ORDER BY PositionQuantity ASC;  
GO 

